#!/bin/bash
#SBATCH -p gpu
#SBATCH --nodes 1
#SBATCH --gres=gpu:a4000:1
#SBATCH --ntasks-per-node 1
#SBATCH --mem=36g
#SBATCH -t 1-0:00:00
#SBATCH -J rf3-hbond-test
#SBATCH -o slurm_logs/%x_%j.out
#SBATCH -e slurm_logs/%x_%j.out
#SBATCH --no-kill=off

## set this path to your modelhub directory. 
# branch name: aa_design/main-atomworks-merge 
# tested on `git checkout c6dc7b019f41793dadf289cf9bafdf163e66612c` (Nov 10, 1 PM)
modelhub=/home/raktim/modelhub_test/

export PROJECT_PATH=$modelhub/projects/aa_design
export PYTHONPATH="$modelhub/src:$modelhub/lib/atomworks/src/"


outdir=./na_tutorial_outputs/
rm $outdir/*
ckpt_path=/projects/ml/aa_design/models/rfd3_latest.ckpt
$modelhub/src/modelhub/inference.py ckpt_path=$ckpt_path out_dir=$outdir inputs=./na_tutorial.json n_batches=2 diffusion_batch_size=3 cleanup_virtual_atoms=True

#some cleanup
rm *.hb2
rm *.pdb
